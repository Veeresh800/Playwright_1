# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: SCRUM-6\flight-search.spec.ts >> SCRUM-6: Flight Search - Air Canada >> TC010 - Airport Autocomplete Functionality
- Location: tests\SCRUM-6\flight-search.spec.ts:355:7

# Error details

```
TimeoutError: locator.waitFor: Timeout 10000ms exceeded.
Call log:
  - waiting for locator('form, [role="search"], .flight-search-form').first() to be visible
    - waiting for" https://www.aircanada.com/home/ca/en/aco/flights" navigation to finish...
    - navigated to "https://www.aircanada.com/home/ca/en/aco/flights"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic:
    - generic:
      - generic:
        - list:
          - listitem:
            - link "Skip to book a flight":
              - /url: "javascript: void(0)"
          - listitem:
            - link "Skip to content":
              - /url: "javascript: void(0)"
          - listitem:
            - link "Skip to main navigation":
              - /url: "javascript: void(0)"
          - listitem:
            - link "Skip to footer links":
              - /url: "javascript: void(0)"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - generic [ref=e9]:
        - link "Air Canada - Go to homepage" [ref=e11]:
          - /url: /
          - img [ref=e13]
        - generic [ref=e27]:
          - search [ref=e30]:
            - generic [ref=e35] [cursor=pointer]:
              - generic [ref=e36]:
                - generic:
                  - generic:
                    - generic: Search
                - searchbox "Search" [ref=e38]
              - button "Search" [ref=e40]:
                - generic [ref=e41]: Search
                - img [ref=e43]
          - complementary "Site edition, language and currency selector" [ref=e47]:
            - button [ref=e49] [cursor=pointer]
          - generic [ref=e52]:
            - link "Join Aeroplan" [ref=e54] [cursor=pointer]:
              - generic:
                - generic: Join Aeroplan
            - link "Sign in" [ref=e57] [cursor=pointer]:
              - generic:
                - generic: Sign in
    - navigation "Main navigation" [ref=e59]:
      - button "View less navigation section details" [expanded] [ref=e61] [cursor=pointer]:
        - img [ref=e63]
      - generic [ref=e69]:
        - generic [ref=e77]:
          - generic [ref=e78]:
            - link "Flights" [ref=e80]:
              - /url: /home/ca/en/aco/flights
              - generic [ref=e81]:
                - img [ref=e84]
                - generic [ref=e86]: Flights
            - link "Packages" [ref=e88]:
              - /url: /home/ca/en/aco/packages
              - generic [ref=e89]:
                - img [ref=e92]
                - generic [ref=e94]: Packages
            - link "Deals" [ref=e96]:
              - /url: https://www.aircanada.com/en-ca/?acid=INT:ACT:specialoffer:spOffer:::home_side_nav|caen
              - generic [ref=e97]:
                - img [ref=e100]
                - generic [ref=e102]: Deals
          - generic [ref=e103]:
            - link "Trips" [ref=e107]:
              - /url: /home/ca/en/aco/trips
              - generic [ref=e108]:
                - img [ref=e111]
                - generic [ref=e113]: Trips
            - link "Check-in" [ref=e115]:
              - /url: /home/ca/en/aco/checkin
              - generic [ref=e116]:
                - img [ref=e119]
                - generic [ref=e121]: Check-in
            - link "Flight status" [ref=e123]:
              - /url: /home/ca/en/aco/flight-status
              - generic [ref=e124]:
                - img [ref=e127]
                - generic [ref=e129]: Flight status
          - generic [ref=e130]:
            - link "Aeroplan" [ref=e134]:
              - /url: /aeroplan/member/dashboard?lang=en-CA
              - generic [ref=e135]:
                - img [ref=e138]
                - generic [ref=e140]: Aeroplan
            - link "Aeroplan offers" [ref=e142]:
              - /url: /aeroplan/member/dashboard/myoffers?lang=en-CA
              - generic [ref=e143]:
                - img [ref=e146]
                - generic [ref=e148]: Aeroplan offers
            - link "eStore. This link opens in a new tab." [ref=e150]:
              - /url: https://aeroplan.rewardops.com/en-CA/home/for-you
              - generic [ref=e155]: eStore
          - generic [ref=e158]:
            - link "Hotels" [ref=e162]:
              - /url: /home/ca/en/aco/hotels
              - generic [ref=e163]:
                - img [ref=e166]
                - generic [ref=e168]: Hotels
            - link "Cars" [ref=e170]:
              - /url: /home/ca/en/aco/cars
              - generic [ref=e171]:
                - img [ref=e174]
                - generic [ref=e176]: Cars
            - link "Flight Passes" [ref=e178]:
              - /url: /home/ca/en/aco/flight-pass
              - generic [ref=e179]:
                - img [ref=e182]
                - generic [ref=e184]: Flight Passes
          - link "More" [ref=e189]:
            - generic [ref=e190]:
              - img [ref=e193]
              - generic [ref=e195]: More
        - link "Accessibility services" [ref=e198]:
          - /url: https://www.aircanada.com/ca/en/aco/home/plan/accessibility.html
          - img [ref=e200]
          - strong [ref=e202]: Accessibility services
  - generic [ref=e205]:
    - main [ref=e206]:
      - generic [ref=e213]:
        - generic [ref=e218]:
          - heading "Where can we take you?" [level=1] [ref=e220]
          - generic [ref=e222]:
            - generic [ref=e223]:
              - button "Choose trip type - currently selected - Round-trip" [ref=e227] [cursor=pointer]:
                - generic:
                  - generic:
                    - generic:
                      - strong: Round-trip
                      - generic:
                        - img
              - generic [ref=e229]:
                - button "Passengers - currently selected - 1 Adult" [ref=e232] [cursor=pointer]:
                  - generic:
                    - generic:
                      - generic:
                        - strong: 1 Adult
                        - generic:
                          - img
                - paragraph [ref=e234]
              - generic [ref=e240]:
                - checkbox "Book with Aeroplan points" [ref=e241] [cursor=pointer]
                - generic [ref=e243] [cursor=pointer]:
                  - img [ref=e245]
                  - strong [ref=e246]: Book with Aeroplan points
            - generic [ref=e249]:
              - generic [ref=e252]:
                - button "Departing from - MAA - Chennai (Madras)" [ref=e255] [cursor=pointer]:
                  - generic [ref=e256]:
                    - paragraph [ref=e257]: MAA
                    - paragraph [ref=e258]: Chennai (Madras)
                - button "Swap origin and destination" [ref=e260] [cursor=pointer]:
                  - img [ref=e262]: s
                - button "Arriving in" [ref=e269] [cursor=pointer]:
                  - generic [ref=e270]:
                    - img [ref=e272]
                    - paragraph [ref=e274]: Arriving in
              - generic [ref=e275]:
                - generic [ref=e277]:
                  - button "Show calendar" [ref=e278] [cursor=pointer]:
                    - img [ref=e280]
                  - generic [ref=e287]:
                    - generic:
                      - generic:
                        - generic: Departure date
                    - combobox "Departure date" [ref=e289]
                  - generic [ref=e295]:
                    - generic:
                      - generic:
                        - generic: Return date
                    - combobox "Return date" [ref=e297]
                - generic:
                  - generic:
                    - definition
                - generic [ref=e298]: "Enter the date, day and month in this format: DD/MM, or press the down arrow key button to open the calendar and select your date from there."
              - generic [ref=e302]:
                - generic [ref=e304]:
                  - generic [ref=e305]:
                    - generic:
                      - generic:
                        - img
                  - generic [ref=e306]:
                    - generic:
                      - generic:
                        - generic: Promotion code
                    - textbox "Promotion code" [ref=e308]:
                      - /placeholder: ""
                - generic:
                  - definition
              - button "Search" [ref=e312] [cursor=pointer]:
                - generic [ref=e313]: Search
            - banner "You're visiting the Canada edition of our website. Based on your location, we recommend using our India edition" [ref=e320]:
              - paragraph [ref=e321]:
                - text: You're visiting the
                - strong [ref=e322]: Canada
                - text: edition of our website. Based on your location, we recommend using our
                - link "India edition" [ref=e323]:
                  - /url: /home/in/en/aco/flights
              - img [ref=e325]
            - region
        - generic [ref=e328]:
          - generic [ref=e331]:
            - heading "Featured flight offers" [level=2] [ref=e332]
            - generic [ref=e336]:
              - heading "Your out-of-office starts here" [level=2] [ref=e337]
              - paragraph [ref=e339]: Save 25% on select base fares worldwide for travel by February 28, 2027. Book by June 8.
              - link "Book now" [ref=e341] [cursor=pointer]:
                - /url: https://www.aircanada.com/en-ca/?acid=INT:ACO:25NtpJune2-8:PRJAC40000146:URL4720:salesbanner#worldwide-CVJU4VK1-modal
                - generic [ref=e342]: Book now
          - generic [ref=e346]:
            - img "3d globe image" [ref=e348]
            - generic [ref=e349]:
              - paragraph [ref=e350]: A WORLD OF DEALS
              - heading "Still searching for that special somewhere? We’ll get you there." [level=2] [ref=e351]
              - link "See offers" [ref=e353] [cursor=pointer]:
                - /url: https://www.aircanada.com/en-ca/?acid=INT:ACO:AEJanFlame2026:PRJNE4077:URL4129:homepageaebanner#aeoffer-modal
                - generic [ref=e354]: See offers
              - generic [ref=e358]:
                - figure "destinations" [ref=e360]:
                  - paragraph [ref=e361]: "0"
                  - generic [ref=e362]: destinations
                - figure "daily flights" [ref=e364]:
                  - paragraph [ref=e365]: "0"
                  - generic [ref=e366]: daily flights
                - figure "continents" [ref=e368]:
                  - paragraph [ref=e369]: "0"
                  - generic [ref=e370]: continents
          - generic [ref=e374]:
            - heading "New to Air Canada" [level=2] [ref=e375]
            - list [ref=e379]:
              - listitem [ref=e380]:
                - generic [ref=e383]:
                  - heading "Welcome back to our Montréal Maple Leaf Lounge" [level=3] [ref=e384]
                  - paragraph [ref=e385]: Refreshed, reopened and ready to welcome you in the domestic terminal.
                  - link "Learn more. This link opens in a new tab." [ref=e387] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/fly/premium-services/maple-leaf-lounges/maple-leaf-lounge-details.html?acid=INT:EVE:POSCAYULDOMMLL:PRJAER40000208:URL4513::ACapp#/!lounge@montreal
                    - generic [ref=e388]: Learn more
                    - img [ref=e391]
              - listitem [ref=e393]:
                - generic [ref=e396]:
                  - heading "Building toward a more inclusive journey" [level=3] [ref=e397]
                  - paragraph [ref=e398]: Designed to help travellers feel more supported on their trip.
                  - link "Learn more. This link opens in a new tab." [ref=e400] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/plan/accessibility/accessibility-plan.html?acid=INT:ACO:accessibilitycampaign2026:prjac40000141:url4699:newacoplanen#/
                    - generic [ref=e401]: Learn more
                    - img [ref=e404]
              - listitem [ref=e406]:
                - generic [ref=e409]:
                  - heading "Your support means the world" [level=3] [ref=e410]
                  - paragraph [ref=e411]: Cast your vote for Air Canada in the 2026 Skytrax World Airline Awards!
                  - link "Vote now. This link opens in a new tab." [ref=e413] [cursor=pointer]:
                    - /url: https://www.worldairlinesurvey.com/Surveys/favourite_airline.html
                    - generic [ref=e414]: Vote now
                    - img [ref=e417]
          - generic [ref=e420]:
            - heading "Travel news and updates" [level=2] [ref=e421]
            - generic [ref=e422]:
              - generic [ref=e423]:
                - img "Travel news and updates" [ref=e425]
                - generic [ref=e426]:
                  - heading "Review travel requirements for your trip" [level=3] [ref=e427]
                  - paragraph [ref=e428]: Review the latest travel requirements and find answers to your frequently asked questions.
                  - separator [ref=e429]
                  - link "Visit Travel Ready hub. Opens in a new tab" [ref=e431] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/plan/travel-requirements/travel-ready-hub.html
                    - generic:
                      - generic:
                        - text: Visit Travel Ready hub
                        - generic:
                          - generic:
                            - img
              - list [ref=e433]:
                - listitem [ref=e434]:
                  - link "Military situation in the Middle East. Opens in a new tab" [ref=e436] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/book/travel-news-and-updates/2026/middle-east-travel.html
                    - generic:
                      - generic:
                        - text: Military situation in the Middle East
                        - generic:
                          - generic:
                            - img
                - listitem [ref=e437]:
                  - link "Baggage fee changes. Opens in a new tab" [ref=e439] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/book/travel-news-and-updates/baggage-fee-changes.html
                    - generic:
                      - generic:
                        - text: Baggage fee changes
                        - generic:
                          - generic:
                            - img
                - listitem [ref=e440]:
                  - link "EU Entry/Exit System – expect delays at European airports. Opens in a new tab" [ref=e442] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/book/travel-news-and-updates/2025/eu-introduces-entry-exit-system.html
                    - generic:
                      - generic:
                        - text: EU Entry/Exit System – expect delays at European airports
                        - generic:
                          - generic:
                            - img
                - listitem [ref=e443]:
                  - link "Travelling through Montréal?. Opens in a new tab" [ref=e445] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/book/travel-news-and-updates/2026/travelling-through-montreal.html
                    - generic:
                      - generic:
                        - text: Travelling through Montréal?
                        - generic:
                          - generic:
                            - img
                - listitem [ref=e446]:
                  - link "Travel to or from Cuba. Opens in a new tab" [ref=e448] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco//home/book/travel-news-and-updates/2026/travel-to-from-cuba.html
                    - generic:
                      - generic:
                        - text: Travel to or from Cuba
                        - generic:
                          - generic:
                            - img
                - listitem [ref=e449]:
                  - link "More news. Opens in a new tab" [ref=e451] [cursor=pointer]:
                    - /url: https://www.aircanada.com/ca/en/aco/home/book/travel-news-and-updates.html
                    - generic:
                      - generic:
                        - text: More news
                        - generic:
                          - generic:
                            - img
    - contentinfo [ref=e453]:
      - generic [ref=e455]:
        - link "Air Canada - Go to homepage" [ref=e457]:
          - /url: /home/ca/en/aco/flights
          - img "Air Canada" [ref=e459]
        - generic:
          - link "A Star Alliance member Opens in a new tab":
            - /url: https://www.staralliance.com/en/home
            - img "A Star Alliance member Opens in a new tab"
      - generic [ref=e474]:
        - generic [ref=e475]:
          - heading "Support" [level=3] [ref=e477]
          - link "Help and contact. This link opens in a new tab." [ref=e479]:
            - /url: /ca/en/aco/home/fly/customer-support/contact-us.html
            - text: Help And Contact
          - link "Baggage & optional service fees. This link opens in a new tab." [ref=e481]:
            - /url: https://www.aircanada.com/ca/en/aco/home/legal/products-and-services.html
            - text: Baggage & Optional Service Fees
          - link "Customer service plan. This link opens in a new tab." [ref=e483]:
            - /url: /ca/en/aco/home/legal/air-canada-customer-service-plan.html
            - text: Customer Service Plan
          - link "The Air Canada Cybersecurity Centre. This link opens in a new tab." [ref=e485]:
            - /url: /ca/en/aco/home/book/travel-news-and-updates/telephone-and-email-scams.html
            - text: The Air Canada Cybersecurity Centre
        - generic [ref=e486]:
          - heading "Air Canada" [level=3] [ref=e488]
          - link "Media centre. This link opens in a new tab." [ref=e490]:
            - /url: https://www.aircanada.com/ca/en/aco/home/about/media.html
            - text: Media Centre
          - link "Official languages. This link opens in a new tab." [ref=e492]:
            - /url: https://www.aircanada.com/ca/en/aco/home/about/official-languages.html#/
            - text: Official Languages
          - link "Leave Less. This link opens in a new tab." [ref=e494]:
            - /url: https://leaveless.aircanada.com/ca/en/index.html
            - text: Leave Less
          - link "Our stories. This link opens in a new tab." [ref=e496]:
            - /url: /ca/en/aco/home/video-hub.html
            - text: Our Stories
          - link "Investor relations. This link opens in a new tab." [ref=e498]:
            - /url: https://www.aircanada.com/ca/en/aco/home/about/investor-relations.html
            - text: Investor Relations
          - link "Careers. This link opens in a new tab." [ref=e500]:
            - /url: https://www.aircanada.com/ca/en/aco/home/about/careers.html
            - text: Careers
          - link "Modern slavery report. This link opens in a new tab." [ref=e502]:
            - /url: https://content.presspage.com/uploads/3174/2b516d6a-25c7-40c1-a648-cc3c84a7712c/2025-modernslavery-report-en-final.pdf?10000
            - text: Modern Slavery Report
          - link "Diversity, Equity and Inclusion. This link opens in a new tab." [ref=e504]:
            - /url: https://www.aircanada.com/ca/en/aco/home/about/diversity-equity-inclusion.html
            - text: Diversity, Equity And Inclusion
        - generic [ref=e505]:
          - heading "Other services" [level=3] [ref=e507]
          - link "Air Canada for Business. This link opens in a new tab." [ref=e509]:
            - /url: /ca/en/aco/home/book/business-travel.html
            - text: Air Canada For Business
          - link "Air Canada for travel agents. This link opens in a new tab." [ref=e511]:
            - /url: https://acconnex.aircanada.com/home/login
            - text: Air Canada For Travel Agents
          - link "Air Canada Cargo. This link opens in a new tab." [ref=e513]:
            - /url: http://www.aircanada.com/cargo/en/
            - text: Air Canada Cargo
          - link "Air Canada Foundation. This link opens in a new tab." [ref=e515]:
            - /url: https://www.aircanada.com/en/about/community/foundation/index.html
            - text: Air Canada Foundation
        - generic [ref=e516]:
          - heading "Our awards" [level=3] [ref=e518]
          - generic [ref=e522]:
            - img "Skytrax" [ref=e523]
            - generic [ref=e524]: Best Airline in North America
      - generic [ref=e526]:
        - generic [ref=e528]: © 2026 Air Canada
        - generic [ref=e530]:
          - link "Terms of use. This link opens in a new tab." [ref=e532]:
            - /url: https://www.aircanada.com/ca/en/aco/home/legal/terms-of-use.html
            - text: "| Terms of use"
          - link "Privacy policy. This link opens in a new tab." [ref=e534]:
            - /url: https://www.aircanada.com/ca/en/aco/home/legal/privacy-policy.html
            - text: "| Privacy policy"
          - link "General Conditions of Carriage & Tariffs. This link opens in a new tab." [ref=e536]:
            - /url: https://www.aircanada.com/ca/en/aco/home/legal/conditions-carriage-tariffs.html
            - text: "| General Conditions of Carriage & Tariffs"
          - link "Cookie and tracking technologies policy. This link opens in a new tab." [ref=e538]:
            - /url: https://www.aircanada.com/ca/en/aco/home/legal/cookie-policy.html
            - text: Cookie and tracking technologies policy
        - generic [ref=e541]:
          - link "Facebook. This link opens in a new tab." [ref=e542]:
            - /url: https://www.facebook.com/aircanada?src=footer
            - img [ref=e544]
          - link "Visit our X page. This link opens in a new tab." [ref=e546]:
            - /url: https://twitter.com/aircanada?src=footer
            - img [ref=e548]
          - link "Subscribe to our YouTube channel. This link opens in a new tab." [ref=e550]:
            - /url: https://www.youtube.com/user/aircanada?src=footer
            - img [ref=e552]
```

# Test source

```ts
  1   | import { Page, expect } from '@playwright/test';
  2   | 
  3   | export class FlightSearchPage {
  4   |   readonly page: Page;
  5   | 
  6   |   // Locators
  7   |   readonly tripTypeSelector = '[data-testid="trip-type-selector"], [aria-label*="trip"], .trip-type-selector, select[name="tripType"]';
  8   |   readonly oneWayOption = '[data-testid="one-way"], text=One-way, [value="oneWay"]';
  9   |   readonly roundTripOption = '[data-testid="round-trip"], text=Round-trip, [value="roundTrip"]';
  10  |   readonly departureAirportInput = '[data-testid="departure-airport"], [placeholder*="departure"], [placeholder*="From"], input[name="departureAirport"]';
  11  |   readonly destinationAirportInput = '[data-testid="destination-airport"], [placeholder*="destination"], [placeholder*="To"], input[name="destinationAirport"]';
  12  |   readonly departureDate = '[data-testid="departure-date"], [placeholder*="departure date"], input[name="departureDate"]';
  13  |   readonly returnDate = '[data-testid="return-date"], [placeholder*="return date"], input[name="returnDate"]';
  14  |   readonly passengerCountSelector = '[data-testid="passenger-count"], [aria-label*="passenger"], select[name="passengers"]';
  15  |   readonly searchButton = '[data-testid="search-button"], button:has-text("Search"), button:has-text("Find flights")';
  16  |   readonly autocompleteSuggestions = '[data-testid="autocomplete-suggestions"], .autocomplete-list, ul[role="listbox"]';
  17  |   readonly suggestionItem = '[data-testid^="suggestion"], .suggestion-item';
  18  |   readonly calendarPicker = '.calendar, [role="dialog"]';
  19  |   readonly dateInput = 'input[type="date"]';
  20  | 
  21  |   constructor(page: Page) {
  22  |     this.page = page;
  23  |   }
  24  | 
  25  |   // Navigation
  26  |   async goto() {
  27  |     await this.page.goto('https://www.aircanada.com/home/ca/en/aco/flights', {
  28  |       waitUntil: 'networkidle',
  29  |       timeout: 30000,
  30  |     });
  31  |   }
  32  | 
  33  |   async pageLoaded() {
  34  |     // Wait for search form to be visible
  35  |     const searchForm = this.page.locator('form, [role="search"], .flight-search-form').first();
> 36  |     await searchForm.waitFor({ state: 'visible', timeout: 10000 });
      |                      ^ TimeoutError: locator.waitFor: Timeout 10000ms exceeded.
  37  |     return true;
  38  |   }
  39  | 
  40  |   // Trip Type Selection
  41  |   async selectTripType(tripType: 'One-way' | 'Round-trip' | 'Multi-city') {
  42  |     try {
  43  |       // Try data-testid first
  44  |       const selector = this.page.locator('[data-testid="trip-type-selector"]').first();
  45  |       
  46  |       if (await selector.isVisible()) {
  47  |         await selector.click();
  48  |         
  49  |         if (tripType === 'One-way') {
  50  |           await this.page.locator('text=One-way, >> nth=0').click();
  51  |         } else if (tripType === 'Round-trip') {
  52  |           await this.page.locator('text=Round-trip').first().click();
  53  |         }
  54  |       } else {
  55  |         // Fallback: Look for radio buttons or buttons
  56  |         await this.page.locator(`text=${tripType}`).first().click();
  57  |       }
  58  |       
  59  |       await this.page.waitForTimeout(500);
  60  |     } catch (e) {
  61  |       console.log(`Could not select trip type using standard methods: ${e}`);
  62  |       throw new Error(`Failed to select trip type: ${tripType}`);
  63  |     }
  64  |   }
  65  | 
  66  |   // Airport Selection
  67  |   async selectDepartureAirport(airport: string, airportCode: string) {
  68  |     const input = this.page.locator(this.departureAirportInput).first();
  69  |     await input.click();
  70  |     await input.fill(airport);
  71  |     
  72  |     // Wait for autocomplete suggestions
  73  |     await this.page.waitForTimeout(300);
  74  |     
  75  |     // Look for suggestion containing the airport code
  76  |     const suggestion = this.page.locator(`text=${airportCode}`).first();
  77  |     
  78  |     try {
  79  |       await suggestion.waitFor({ state: 'visible', timeout: 5000 });
  80  |       await suggestion.click();
  81  |     } catch {
  82  |       // If autocomplete didn't appear, try direct input
  83  |       await input.clear();
  84  |       await input.fill(`${airport} (${airportCode})`);
  85  |     }
  86  |   }
  87  | 
  88  |   async selectDestinationAirport(airport: string, airportCode: string) {
  89  |     const input = this.page.locator(this.destinationAirportInput).first();
  90  |     await input.click();
  91  |     await input.fill(airport);
  92  |     
  93  |     // Wait for autocomplete suggestions
  94  |     await this.page.waitForTimeout(300);
  95  |     
  96  |     // Look for suggestion containing the airport code
  97  |     const suggestion = this.page.locator(`text=${airportCode}`).first();
  98  |     
  99  |     try {
  100 |       await suggestion.waitFor({ state: 'visible', timeout: 5000 });
  101 |       await suggestion.click();
  102 |     } catch {
  103 |       // If autocomplete didn't appear, try direct input
  104 |       await input.clear();
  105 |       await input.fill(`${airport} (${airportCode})`);
  106 |     }
  107 |   }
  108 | 
  109 |   // Date Selection
  110 |   async selectDepartureDate(daysFromNow: number = 7) {
  111 |     const input = this.page.locator(this.departureDate).first();
  112 |     
  113 |     // Calculate the date
  114 |     const date = new Date();
  115 |     date.setDate(date.getDate() + daysFromNow);
  116 |     const formattedDate = date.toISOString().split('T')[0];
  117 |     
  118 |     await input.click();
  119 |     
  120 |     // Try HTML5 date input
  121 |     try {
  122 |       await input.fill(formattedDate);
  123 |     } catch {
  124 |       // Try clicking calendar picker
  125 |       const datePicker = this.page.locator(this.calendarPicker).first();
  126 |       if (await datePicker.isVisible()) {
  127 |         const dateButton = datePicker.locator(`button:has-text("${date.getDate()}")`).first();
  128 |         await dateButton.click();
  129 |       }
  130 |     }
  131 |   }
  132 | 
  133 |   async selectReturnDate(daysFromNow: number = 10) {
  134 |     const input = this.page.locator(this.returnDate).first();
  135 |     
  136 |     // Calculate the date
```